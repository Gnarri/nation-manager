let countryInfo;

document.getElementById('pin').addEventListener('keypress', function(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      
      const pin = this.value;
      
      fetch('/rulerpin', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ pin })
      })
      .then(response => response.json())
      .then(data => {
        countryInfo = data;
        console.log('Country information:', data);
        updateData();
        return
      })
      .catch(error => console.error('Error fetching country information:', error));
    }
  });
function updateData() {
    document.getElementById('land').value = countryInfo.military.land
    document.getElementById('naval').value = countryInfo.military.naval
    document.getElementById('air').value = countryInfo.military.air
    document.getElementById('nuke').value = countryInfo.military.nuke
    document.getElementById('military-spending').value = countryInfo.military.spending
    document.getElementById('country-name').innerHTML = countryInfo.name
    document.getElementById('size').value = countryInfo.size
    document.getElementById('country-flag').src = countryInfo.flag_url
    document.getElementById('tax').value = countryInfo.tax_setting
    document.getElementById('stab').value = countryInfo.stability.spending
}
function updateCountry() {
  console.log('Country update requested')
  const land = document.getElementById('land').value 
  const naval = document.getElementById('naval').value 
  const air = document.getElementById('air').value 
  const nuke = document.getElementById('nuke').value 
  const milspend = document.getElementById('military-spending').value 
  const name = document.getElementById('name').value 
  const size = document.getElementById('size').value 
  const taxset = document.getElementById('tax').value
  const stabspend = document.getElementById('stab').value

  const updatedCountryData = {
    name: name,
    military: {
      land: land,
      naval: naval,
      air: air,
      nuke: nuke,
      spending: milspend,
    },
    size: size,
    tax_setting: taxset,
    stability: {
      spending: stabspend,
      stability: countryInfo.stability.stability,
      change: countryInfo.stability.change
    }
  };

  fetch('/update-country', {
    method: 'POST',
    body: JSON.stringify(updatedCountryData),
    headers: {
      'Content-Type': 'application/json'
    }
  })
  .then(response => response.text())
  .then(message => alert(message))
  .catch(error => console.error('Error updating data:', error));
}
