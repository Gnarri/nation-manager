let hovering = false;
let hover = document.getElementById("fc");
hover.style.display = 'none';

let countriesData;

// Fetch data from server on DOMContentLoaded
document.addEventListener("DOMContentLoaded", function() {
    fetch('/countries')
        .then(response => response.json())
        .then(data => {
            // Check if data contains the 'countries' array
            if (Array.isArray(data.countries)) {
                countriesData = data.countries;
                populateCountries();
            } else {
                console.error('Error fetching countries: Data is not in expected format');
            }
        })
        .catch(error => console.error('Error fetching countries:', error));
});

// Populate countries
function populateCountries() {
  const countriesContainer = document.querySelector('.countries-container');
  
  // Loop through each country data in the JSON data
  countriesData.forEach((countryData, index) => {
      // Clone the template div element
      const countryTemplate = document.getElementById('template');
      const countryElement = countryTemplate.cloneNode(true);
      
      // Set the ID of the cloned element to the index of the data
      countryElement.id = index;

      // Update information within the cloned element
      countryElement.querySelector('.country-name').textContent = countryData.name;
      countryElement.querySelector('.country-flag').src = countryData.flag_url;
      countryElement.querySelector('#country-pop').textContent = formatNumber(countryData.population.population);
      countryElement.querySelector('#country-stability').textContent = countryData.stability.stability + "%";
      countryElement.querySelector('#country-military').textContent = formatNumber(countryData.military.military_power);
      countryElement.querySelector('#country-money').textContent = "$" + formatNumber(countryData.treasury);
      countryElement.querySelector('#country-size').textContent = formatNumber(countryData.size);
      
      // Show the cloned element
      countryElement.style.display = 'block';
      
      // Append the cloned and updated element to the countries container
      countriesContainer.appendChild(countryElement);

      // Add event listeners for mouseover and mouseleave events to each country element
      countryElement.addEventListener('mouseover', handleMouseOver);
      countryElement.addEventListener('mouseleave', handleMouseLeave);
  });
  document.getElementById('template').remove();
}

// Handle mouseover event
function handleMouseOver(event) {
  const hoveredElement = event.target;
  const countryInfoElement = hoveredElement.closest('.country-info');
  const countryElement = hoveredElement.closest('.country');
  const countryId = countryElement.id;
  const countryData = countriesData[countryId];
  hover.style.display = 'inline';
  hovering = true;

  if (countryInfoElement) {
      const infoId = countryInfoElement.querySelector('h1').id;

      // Handle hover over different information elements
      switch (infoId) {
          case 'country-pop':
              hover.innerHTML = `${formatNumber(countryData.population.population)} People<br>+${formatNumber(countryData.population.increase)} Daily`
              break;
          case 'country-stability':
              hover.innerHTML = `${formatNumber(countryData.stability.stability)}%<br>$${formatNumber(countryData.stability.spending)} Spending<br>${countryData.stability.change} Daily`
              break;
          case 'country-military':
              hover.innerHTML = `${formatNumber(countryData.military.land)} Land units<br>${formatNumber(countryData.military.naval)} Naval units<br>${formatNumber(countryData.military.air)} Air units<br>${formatNumber(countryData.military.nuke)} Nukes<br>$${formatNumber(countryData.military.spending)} Spending`
              break;
          case 'country-money':
              hover.innerHTML = `Income: $${formatNumber(countryData.income)}<br>Expenses: $${formatNumber(countryData.expenses)}<br>Tax: $${formatNumber(countryData.tax_setting)}/person`
              break;
          default:
              console.log('Unknown Information Element');
      }
  }
}
// formatNumber()

// Handle mouseleave event
function handleMouseLeave(event) {
    hovering = false;
    hover.style.display = 'none';
    hover.innerHTML = '';
}

// Retrieve country data from the DOM

// End hover end
function isTouchDevice() {
  try {
    document.createEvent("TouchEvent");
    return true;
  } catch (e) {
    return false;
  }
}
const move = (e) => {
  try {
    var x = !isTouchDevice() ? e.pageX : e.touches[0].pageX;
    var y = !isTouchDevice() ? e.pageY : e.touches[0].pageY;
  } catch (e) {}
  hover.style.left = x  + "px";
  hover.style.top = y  + "px";
};
document.addEventListener("mousemove", (e) => {
  move(e);
});
document.addEventListener("touchmove", (e) => {
  move(e);
});
function formatNumber(number) {
  if (!number && number !== 0) {
    console.warn('Attempted to locale string an undefined variable!', number)
    return number;
  }
  return number.toLocaleString();
}