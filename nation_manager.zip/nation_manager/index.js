const express = require('express');
const app = express();
const fs = require('fs');
const bodyParser = require('body-parser');
const cron = require('node-cron');

app.use(bodyParser.json());
app.use(express.static('main'));

cron.schedule('0 0 * * *', () => {
  updateCountryData();
}, {
  timezone: 'America/Chicago'
});

app.get('/countries', (req, res) => {
  const countriesData = JSON.parse(fs.readFileSync('countries.json'));
  res.json(countriesData);
});

app.post('/rulerpin', (req, res) => {
  fs.readFile('rulers.json', 'utf8', (err, rulersData) => {
    if (err) {
      console.error('Error reading rulers.json:', err);
      return res.status(500).send('Internal Server Error');
    }
    const rulers = JSON.parse(rulersData);
    const { pin } = req.body;

    const ruler = rulers.rulers.find(entry => entry.pin === pin);

    if (!ruler) {
      return res.status(404).send('No country found with that PIN.');
    }

    fs.readFile('countries.json', 'utf8', (err, countriesData) => {
      if (err) {
        console.error('Error reading countries.json:', err);
        return res.status(500).send('Internal Server Error');
      }
      const countries = JSON.parse(countriesData);
      const country = countries.countries.find(country => country.name === ruler.country);

      if (!country) {
        return res.status(404).send('Country not found.');
      }

      res.json(country);
    });
  });
});

const parseNumericValues = (obj) => {
  for (const key in obj) {
    if (typeof obj[key] === 'object') {
      parseNumericValues(obj[key]);
    } else if (!isNaN(obj[key])) {
      obj[key] = parseFloat(obj[key]);
    }
  }
};
//updateCountryData();
app.post('/update-country', (req, res) => {
  const updatedFields = req.body;
  fs.readFile('countries.json', 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading countries.json:', err);
      return res.status(500).send('Internal Server Error');
    }

    let countriesData = JSON.parse(data);

    const index = countriesData.countries.findIndex(country => country.name === updatedFields.name);

    if (index !== -1) {
      // marse numeric values in updated fields
      parseNumericValues(updatedFields);

      // merge updated fields with existing country data
      countriesData.countries[index] = { ...countriesData.countries[index], ...updatedFields };

      fs.writeFile('countries.json', JSON.stringify(countriesData, null, 2), err => {
        if (err) {
          console.error('Error writing to countries.json:', err);
          return res.status(500).send('Internal Server Error');
        }
        console.log(`Country "${updatedFields.name}" data updated successfully.`);
        res.send('Country data updated successfully.');
      });
    } else {
      res.status(404).send('Country not found.');
    }
  });
});

const PORT = process.env.PORT || 80;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
function updateCountryData() {
  try {
    const rawData = fs.readFileSync('countries.json');
    let countriesData = JSON.parse(rawData);

    countriesData.countries.forEach(country => {
      const stabilityIncrease = 1 * ((country.stability.spending / 1000000000) - 1 * (country.tax_setting / 1000) - 1 * country.size);
      const stabilityChange = parseFloat(country.stability.stability) + stabilityIncrease;
      const taxIncome = country.population.population * country.tax_setting;
      const resourceIncome = 500000 * country.size;

      const navalPower = country.military.naval * 2;
      const landPower = country.military.land * 2;
      const airPower = country.military.air * 2;
      const nukePower = country.military.nuke * 1000000;
      const militarySpending = country.military.spending / 1000000;
      const militaryPower = (navalPower + landPower + airPower + nukePower) * militarySpending;

      const populationIncrease = country.population.population + country.population.increase + Math.floor(Math.random() * (1000 - 1 + 1)) + 1;
      const income = taxIncome + resourceIncome + Math.floor(Math.random() * (10000000 - 1000000 + 1)) + 1000000;
      const expenses = (parseFloat(country.stability.spending) + country.military.spending + country.size * 1000000) + Math.floor(Math.random() * (10000000 - 1000000 + 1)) + 1000000;
      const balance = income - expenses;
      const treasury = country.treasury + balance;

      country.stability.change = stabilityIncrease.toFixed(2);
      country.stability.stability = stabilityChange.toFixed(2);
      country.income = income;
      country.expenses = expenses;
      country.balance = balance;
      country.treasury = treasury;
      country.military.military_power = militaryPower;
      country.population.population = populationIncrease;
      console.log(`Updated data for ${country.name}:`, country);
    });

    fs.writeFileSync('countries.json', JSON.stringify(countriesData, null, 2));
    console.log('Data updated successfully.');
  } catch (error) {
    console.error('Error updating country data:', error);
  }
}